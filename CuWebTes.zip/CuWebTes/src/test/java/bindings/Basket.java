package bindings;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.assertTrue;

public class Basket {


    WebDriver driver;


    @Given("^that i am in Estimate your take-home pay page$")
    public void that_i_am_in_Estimate_your_take_home_pay_page() throws Throwable {
        driver = new ChromeDriver();
        driver.get("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/your-pay");

    }

    @When("^i enter (\\d+)$")
    public void i_enter(int arg1) throws Throwable {
        driver.findElement(By.cssSelector("#pay-amount")).sendKeys("20000");

    }

    @When("^Select a year option$")
    public void select_a_year_option() throws Throwable {
        driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > form > div:nth-child(2) > fieldset > label:nth-child(6)")).click();
        //Assert.assertEquals(true, driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > form > div:nth-child(2) > fieldset > label:nth-child(6)"))());

    }


    @When("^click continue$")
    public void click_continue() throws Throwable {
        driver.findElement(By.cssSelector("#p-continue")).click();
    }

    @Then("^i can see Are you over the State Pension age\\?$")
    public void i_can_see_Are_you_over_the_State_Pension_age() throws Throwable {
//        Assert.assertEquals(true, driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > h1")).isDisplayed());


    }

    @When("^select option no$")
    public void select_option_no() throws Throwable {
        driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > form > div:nth-child(1) > fieldset > fieldset > label:nth-child(3)")).click();
    }

    @When("^select continue$")
    public void select_continue() throws Throwable {
        driver.findElement(By.cssSelector("#sp-continue")).click();
    }

    @Then("^i can see Do you want to use your current tax code\\?$")
    public void i_can_see_Do_you_want_to_use_your_current_tax_code() throws Throwable {
      //  driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > h1")).click();
        Assert.assertEquals(true, driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > h1")).isDisplayed());

    }

    @When("^i select no$")
    public void i_select_no() throws Throwable {
        driver.findElement(By.cssSelector("#has-tax-code > fieldset > label:nth-child(3)")).click();

    }

    @When("^i select continue$")
    public void i_select_continue() throws Throwable {
        driver.findElement(By.cssSelector("#tc-continue")).click();

    }

    @Then("^i see Do you pay the Scottish Income Tax Rate\\?$")
    public void i_see_Do_you_pay_the_Scottish_Income_Tax_Rate() throws Throwable {
        Assert.assertEquals(true, driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > h1")).isDisplayed());
    }
    @When("^i select-No$")
    public void i_select_No() throws Throwable {
        driver.findElement(By.cssSelector("#content > article > div.grid-layout__column.grid-layout__column--2-3 > form > div:nth-child(1) > fieldset > fieldset > label:nth-child(3)")).click();
    }

    @When("^i select Continue(\\d+)$")
    public void i_select_Continue(int arg1) throws Throwable {
        driver.findElement(By.cssSelector("#sr-continue")).click();
    }
    @Then("^i see Check your answers$")
    public void i_see_Check_your_answers() throws Throwable {
       // driver.findElement(By.cssSelector("#content > article > h1")).click();
        Assert.assertEquals(true, driver.findElement(By.cssSelector("#content > article > h1")).isDisplayed());

    }
    @When("^i select Get Results$")
    public void i_select_Get_Results() throws Throwable {
        driver.findElement(By.cssSelector("#get-results")).click();

    }

    @Then("^i see Your estimated take-home pay$")
    public void i_see_Your_estimated_take_home_pay() throws Throwable {
        //driver.findElement(By.cssSelector("#content > article > div.grid-layout--stacked > div.grid-layout__column.grid-layout__column--2-3 > h1\n")).click();
        Assert.assertEquals(true, driver.findElement(By.cssSelector("#content > article > div.grid-layout--stacked > div.grid-layout__column.grid-layout__column--2-3 > h1\n")).isDisplayed());

    }




}