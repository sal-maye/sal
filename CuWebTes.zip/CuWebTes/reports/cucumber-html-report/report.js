$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("basket.feature");
formatter.feature({
  "line": 3,
  "name": "basket",
  "description": "",
  "id": "basket",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@run"
    }
  ]
});
formatter.scenario({
  "line": 10,
  "name": "Full journey",
  "description": "",
  "id": "basket;full-journey",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "that i am in Estimate your take-home pay page",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "i enter 20000",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Select a year option",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "click continue",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "i can see Are you over the State Pension age?",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "select option no",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "select continue",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "i can see Do you want to use your current tax code?",
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "i select no",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "i select continue",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "i see Do you pay the Scottish Income Tax Rate?",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "i select-No",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "i select Continue1",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "i see Check your answers",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "i select Get Results",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "i see Your estimated take-home pay",
  "keyword": "Then "
});
formatter.match({
  "location": "Basket.that_i_am_in_Estimate_your_take_home_pay_page()"
});
formatter.result({
  "duration": 4846749163,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "20000",
      "offset": 8
    }
  ],
  "location": "Basket.i_enter(int)"
});
formatter.result({
  "duration": 183779585,
  "status": "passed"
});
formatter.match({
  "location": "Basket.select_a_year_option()"
});
formatter.result({
  "duration": 110110244,
  "status": "passed"
});
formatter.match({
  "location": "Basket.click_continue()"
});
formatter.result({
  "duration": 486038757,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_can_see_Are_you_over_the_State_Pension_age()"
});
formatter.result({
  "duration": 85334,
  "status": "passed"
});
formatter.match({
  "location": "Basket.select_option_no()"
});
formatter.result({
  "duration": 94354433,
  "status": "passed"
});
formatter.match({
  "location": "Basket.select_continue()"
});
formatter.result({
  "duration": 488928266,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_can_see_Do_you_want_to_use_your_current_tax_code()"
});
formatter.result({
  "duration": 77054913,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_select_no()"
});
formatter.result({
  "duration": 165218057,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_select_continue()"
});
formatter.result({
  "duration": 592707398,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_see_Do_you_pay_the_Scottish_Income_Tax_Rate()"
});
formatter.result({
  "duration": 47389264,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_select_No()"
});
formatter.result({
  "duration": 108684768,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 17
    }
  ],
  "location": "Basket.i_select_Continue(int)"
});
formatter.result({
  "duration": 419658728,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_see_Check_your_answers()"
});
formatter.result({
  "duration": 54079187,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_select_Get_Results()"
});
formatter.result({
  "duration": 372089544,
  "status": "passed"
});
formatter.match({
  "location": "Basket.i_see_Your_estimated_take_home_pay()"
});
formatter.result({
  "duration": 56928599,
  "status": "passed"
});
});